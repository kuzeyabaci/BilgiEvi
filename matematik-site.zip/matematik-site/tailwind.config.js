/** Renkler afişten alındı */
module.exports = {
  content: ['./app/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        brick: '#D4501F',   // üst bant turuncusu
        leaf: '#8CCB63',    // "Sevmenin Tam Zamanı" yeşili
        ink: '#1E3A41',     // koyu petrol metin
        peach: '#E88B4A',   // madde metinleri
        paper: '#FBFAF7',
      },
      fontFamily: {
        display: ['var(--font-display)', 'sans-serif'],
        body: ['var(--font-body)', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
