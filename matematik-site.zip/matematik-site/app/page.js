const PHONE_DISPLAY = '0507 350 97 21';
const PHONE_HREF = 'tel:+905073509721';

const features = [
  'Kişiye özel ders programı',
  'Hedef odaklı eğitim',
  'Esnek saatler ve birebir ilgi',
  'Anlamaya dayalı öğretim',
];

function Check() {
  return (
    <svg viewBox="0 0 24 24" className="h-7 w-7 shrink-0" aria-hidden="true">
      <circle cx="12" cy="12" r="12" fill="#8CCB63" />
      <path d="M7 12.5l3.2 3.2L17 9" fill="none" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export default function Home() {
  return (
    <main>
      {/* Afişteki dalgalı turuncu bant */}
      <header className="relative bg-brick pb-24 pt-10 text-center sm:pb-32 sm:pt-14">
        <h1 className="mx-auto max-w-3xl px-6 font-display text-3xl font-extrabold uppercase leading-tight tracking-tight text-white sm:text-5xl">
          Matematik korkunuz değil
          <br />
          gücünüz olsun
        </h1>
        <svg viewBox="0 0 1440 120" preserveAspectRatio="none" className="absolute inset-x-0 bottom-0 h-16 w-full sm:h-24" aria-hidden="true">
          <path d="M0 120V70C240 10 480 0 720 40s600 50 720-10v90z" fill="#FBFAF7" />
        </svg>
      </header>

      <section className="mx-auto grid max-w-6xl gap-10 px-6 pb-16 lg:grid-cols-2 lg:gap-16">
        <div>
          <h2 className="font-display text-4xl font-black leading-[1.1] text-leaf sm:text-6xl">
            Matematiği
            <br />
            Sevmenin
            <br />
            Tam Zamanı!
          </h2>
          <div className="my-8 border-t-2 border-dashed border-leaf/60" />
          <p className="max-w-md text-2xl font-medium leading-snug">
            Haydi, hedeflerinize ulaşmanız için <strong className="font-bold">birlikte çalışalım!</strong>
          </p>
        </div>

        <div className="relative">
          <p className="text-xl">Sıkıcı formüllere son!</p>
          <p className="mt-1 max-w-md text-3xl font-bold leading-tight">
            Matematiği anlayarak öğrenmek artık çok kolay.
          </p>

          <ul className="mt-8 space-y-4">
            {features.map((f) => (
              <li key={f} className="flex items-center gap-4 rounded-full border border-leaf/50 bg-white px-5 py-3 shadow-sm">
                <Check />
                <span className="text-xl font-semibold text-peach">{f}</span>
              </li>
            ))}
          </ul>

          {/* Afişteki yeşil yuvarlak rozet */}
          <div className="mt-8 flex h-28 w-28 rotate-[-8deg] items-center justify-center rounded-full border-4 border-yellow-300/70 bg-leaf text-center font-display text-sm font-extrabold uppercase leading-tight text-white lg:absolute lg:-top-20 lg:right-0 lg:mt-0">
            Seferihisar
            <br />
            Bilgi Evi
          </div>
        </div>
      </section>

      <section className="bg-ink text-white">
        <div className="mx-auto flex max-w-6xl flex-col gap-8 px-6 py-14 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="font-display text-xl font-extrabold uppercase tracking-wide">Fatime Dikici</p>
            <p className="mt-1 text-xl">Matematik Öğretmeni · Profesyonel Koç</p>
            <p className="mt-6 text-lg text-white/80">Detaylı bilgi için randevu alınız.</p>
          </div>
          <a
            href={PHONE_HREF}
            className="inline-flex items-center justify-center gap-3 rounded-full bg-brick px-8 py-4 font-display text-2xl font-black text-white transition hover:bg-peach"
          >
            <svg viewBox="0 0 24 24" className="h-6 w-6" fill="currentColor" aria-hidden="true">
              <path d="M6.6 10.8a15 15 0 006.6 6.6l2.2-2.2a1 1 0 011-.25 11 11 0 003.5.56 1 1 0 011 1V20a1 1 0 01-1 1A17 17 0 013 4a1 1 0 011-1h3.5a1 1 0 011 1c0 1.2.2 2.4.56 3.5a1 1 0 01-.25 1z" />
            </svg>
            {PHONE_DISPLAY}
          </a>
        </div>
      </section>
    </main>
  );
}
