export default function AdminHome() {
  return <main className="p-8"><h1 className="text-2xl font-bold">Yönetim paneli</h1></main>;
}
