import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { verifySession, SESSION_COOKIE } from '../../lib/session';

export const dynamic = 'force-dynamic';

// Savunma derinliği: middleware atlatılsa bile sunucuda ikinci kontrol.
export default async function AdminLayout({ children }) {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  if (!(await verifySession(token))) redirect('/login');
  return children;
}
