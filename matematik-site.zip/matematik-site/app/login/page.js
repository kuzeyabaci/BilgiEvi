// İSKELET: Gerçek giriş formu ve oturum çerezi (SESSION_COOKIE) üretimi daha sonra eklenecek.
export default function Login() {
  return (
    <main className="mx-auto max-w-sm px-6 py-24 text-center">
      <h1 className="font-display text-2xl font-extrabold">Yönetici girişi</h1>
      <p className="mt-3">Giriş sistemi henüz kurulmadı.</p>
    </main>
  );
}
