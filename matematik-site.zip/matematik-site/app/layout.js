import './globals.css';
import { Montserrat, Barlow_Semi_Condensed } from 'next/font/google';

const display = Montserrat({ subsets: ['latin', 'latin-ext'], weight: ['800', '900'], variable: '--font-display' });
const body = Barlow_Semi_Condensed({ subsets: ['latin', 'latin-ext'], weight: ['400', '500', '600', '700'], variable: '--font-body' });

export const metadata = {
  title: 'Matematik Korkunuz Değil, Gücünüz Olsun | Fatime Dikici',
  description: 'Seferihisar Bilgi Evi: kişiye özel, hedef odaklı, anlamaya dayalı matematik koçluğu.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="tr" className={`${display.variable} ${body.variable}`}>
      <body>{children}</body>
    </html>
  );
}
