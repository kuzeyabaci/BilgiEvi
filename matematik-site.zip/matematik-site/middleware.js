import { NextResponse } from 'next/server';
import { verifySession, SESSION_COOKIE } from './lib/session';

// Varsayılan: REDDET. Geçerli imzalı admin oturumu yoksa kimse geçemez.
export async function middleware(req) {
  const token = req.cookies.get(SESSION_COOKIE)?.value;
  if (await verifySession(token)) {
    const res = NextResponse.next();
    res.headers.set('Cache-Control', 'no-store');
    return res;
  }

  if (req.nextUrl.pathname.startsWith('/api/')) {
    return NextResponse.json({ error: 'Yetkisiz' }, { status: 401, headers: { 'Cache-Control': 'no-store' } });
  }
  const url = req.nextUrl.clone();
  url.pathname = '/login';
  url.search = '';
  return NextResponse.redirect(url);
}

export const config = {
  matcher: ['/admin', '/admin/:path*', '/api/admin', '/api/admin/:path*'],
};
