# Kurulum
npm install && cp .env.example .env.local   # AUTH_SECRET: `openssl rand -base64 48`
npm run dev
